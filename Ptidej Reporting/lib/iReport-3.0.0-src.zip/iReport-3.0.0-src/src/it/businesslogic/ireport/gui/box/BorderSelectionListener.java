/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package it.businesslogic.ireport.gui.box;

import it.businesslogic.ireport.gui.box.BoxBorderSelectionPanel.Side;
import java.util.List;

/**
 *
 * @author gtoffoli
 */
public interface BorderSelectionListener {

    public void selectionChanged(List<Side> selectedBorders);
    
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package it.businesslogic.ireport.gui;

/**
 *
 * @author gtoffoli
 */
public class PropertyHint {

    private String propertyName = "";
    private String propertyDescription = "";

    public PropertyHint()
    {
    }
    
    public PropertyHint(String propertyName, String propertyDescription)
    {
        this.propertyName = propertyName;
        this.propertyDescription = propertyDescription;
    }
    
    public String getPropertyName() {
        return propertyName;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public String getPropertyDescription() {
        return propertyDescription;
    }

    public void setPropertyDescription(String propertyDescription) {
        this.propertyDescription = propertyDescription;
    }
    
    
}

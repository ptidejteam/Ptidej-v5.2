/*
 * FieldsContainer.java
 * 
 * Created on May 15, 2007, 4:41:46 PM
 * 
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package it.businesslogic.ireport.gui.dnd;

import it.businesslogic.ireport.JRField;

/**
 *
 * @author gtoffoli
 */
public interface FieldsContainer {

    public void addField(JRField f);

}

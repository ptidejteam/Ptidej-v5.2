package padl.analysis.micropattern.detection;

import java.util.Iterator;

import padl.analysis.micropattern.IMicroPatternDetection;
import padl.kernel.IAbstractMethod;
import padl.kernel.IClass;
import padl.kernel.IEntity;
import padl.kernel.IField;
import padl.kernel.IInterface;

public class PoolDetection
	extends AbstractMicroPatternDetection
	implements IMicroPatternDetection {

	public String getName() {
		return "PoolDetection";
	}

	/*
	 * 	4. Pool. The most degenerate classes are those which have neither
	 *	state nor behavior. Such a class is distinguished by the requirement
	 *	that it declares no instance �?elds. Moreover, all of its declared static
	 *	�?elds must be �?nal . Another requirement is that the class has no
	 *	methods (other than those inherited from Object, or automatically
	 *	generated constructors).
	 *	A Pool is a class de�?ned by these requirements. It serves a the
	 *	purpose of grouping together a set of named constants.
	 *	Programmers often use interfaces for the Pool micro pattern.
	 *	For example, package javax.swing includes interface Swing-
	 *	Constants which de�?nes constants used in positioning and ori-
	 *	enting screen components.
	 *	The pattern, also called “constant interface anti-pattern�? [7], makes
	 *	it possible to incorporate a name space of de�?nitions into a class by
	 *	adding an implements clause to that class.
	 */

	public boolean detect(IEntity anEntity) {
		if ((anEntity instanceof IClass)
			|| (anEntity instanceof IInterface)) {
			final Iterator iterator = anEntity.getIteratorOnActors();

			while (iterator.hasNext()) {
				final Object anOtherEntity = iterator.next();

				// Check for method behavior
				if (anOtherEntity instanceof IAbstractMethod) {
					final IAbstractMethod currentMethod =
						(IAbstractMethod) anOtherEntity;

					// Detect static attribute initialization
					if (!currentMethod.getName().equals("<clinit>")
						&& (!currentMethod.getID().startsWith("<init>"))) {

						// The method must be inherited from Object
						final String methodName = currentMethod.getName();
						if (!((methodName.equals("clone"))
							|| (methodName.equals("equals"))
							|| (methodName.equals("finalize"))
							|| (methodName.equals("hashCode"))
							|| (methodName.equals("toString")))) {

							return false;
						}
					}
				}

				// All Fields must be "static final"
				if (anOtherEntity instanceof IField) {
					final IField currentField = (IField) anOtherEntity;
					if ((!currentField.isStatic())
						|| (!currentField.isFinal())) {
						return false;
					}
				}
			}

			this.addEntities(anEntity);
			return true;
		}
		return false;
	}

}

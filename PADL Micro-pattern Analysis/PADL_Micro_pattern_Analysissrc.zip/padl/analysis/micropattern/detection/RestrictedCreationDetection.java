package padl.analysis.micropattern.detection;

import java.util.Iterator;

import padl.analysis.micropattern.IMicroPatternDetection;
import padl.kernel.IClass;
import padl.kernel.IConstructor;
import padl.kernel.IEntity;
import padl.kernel.IField;

public class RestrictedCreationDetection
	extends AbstractMicroPatternDetection
	implements IMicroPatternDetection {

	public String getName() {
		return "RestrictedCreationDetection";
	}

	/*
	 *  11. Restricted Creation. A class with no public constructors, and at
	 *	least one static �?eld of the same type as the class, matches the
	 *	Restricted Creation micro pattern.
	 *	Many S I N G L E T O N classes satisfy this criteria. A famous example
	 *	is java.lang.Runtime.
	 */

	public boolean detect(final IEntity anEntity) {
		// Only Class can be Restricted Creation
		if (anEntity instanceof IClass) {

			final Iterator iterator = anEntity.getIteratorOnActors();

			boolean found = false;
			final String className = ((IEntity) anEntity).getID();

			while (iterator.hasNext()) {
				final Object anOtherEntity = iterator.next();

				// Cannot have a plublic constructor
				if (anOtherEntity instanceof IConstructor) {

					// BIG HACK - WAZZ UP
					// TODO: Remove the hack...
					final IConstructor currentMethod =
						(IConstructor) anOtherEntity;

					if (currentMethod.getID().startsWith("<init>")) {
						if (currentMethod.isPublic()) {
							return false;
						}
					}
					// Need at least one static field of the same type of the class
				}
				else if (
					(anOtherEntity instanceof IField)
						&& (((IField) anOtherEntity).isStatic())
						&& (((IField) anOtherEntity).getType() == className)) {
					found = true;
				}
			}

			if (found) {
				this.addEntities(anEntity);
				return true;
			}
			else {
				return false;
			}
		}
		return false;
	}
}

package padl.analysis.micropattern.detection;

import java.util.Iterator;

import padl.analysis.micropattern.IMicroPatternDetection;
import padl.kernel.IClass;
import padl.kernel.IEntity;
import padl.kernel.IField;

public class CommonStateDetection
	extends AbstractMicroPatternDetection
	implements IMicroPatternDetection {

	public String getName() {
		return "CommonStateDetection";
	}

	/*
	 *  9. Common State. At the next level of complexity, stand classes
	 *	that maintain state, but this state is shared by all of their instances.
	 *	Speci�?cally, a class that has no instance �?elds, but at least one static
	 *	�?eld is a Common State.
	 *	For example, the class System manages (among other things) the
	 *	global input, output, and error streams.
	 *	A Common State with no instance methods is in fact an incarnation
	 *	of the modular programming paradigm in the JAVA world.
	 */

	public boolean detect(final IEntity anEntity) {
		int nbStaticField = 0;

		// Only Class can be Commen State
		if (anEntity instanceof IClass) {
			final Iterator iterator =
				anEntity.getIteratorOnActors(IField.class);

			while (iterator.hasNext()) {
				final Object anOtherEntity = iterator.next();

				// All field must be static
				if (anOtherEntity instanceof IField) {
					if (!((IField) anOtherEntity).isStatic()) {
						return false;
					}
					else {
						nbStaticField++;
					}
				}
			}

			// Must have at least one static field
			if (nbStaticField >= 1) {
				this.addEntities(anEntity);
				return true;
			}
			else {
				return false;
			}
		}
		return false;
	}
}

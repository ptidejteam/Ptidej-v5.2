package padl.analysis.micropattern.detection;

import java.util.Iterator;

import padl.analysis.micropattern.IMicroPatternDetection;
import padl.kernel.IAbstractMethod;
import padl.kernel.IClass;
import padl.kernel.IEntity;
import padl.kernel.IField;

public class FunctionObjectDetection
	extends AbstractMicroPatternDetection
	implements IMicroPatternDetection {

	public String getName() {
		return "FunctionObjectDetection";
	}

	/*
	 * 	6. Function Object. The Function Object micro pattern is similar
	 *	to the Function Pointer micro pattern. The only difference is that
	 *	Function Object has instance �?elds (which are often set by the class
	 *	constructor). Thus, an instance of Function Object class can store
	 *	parameters to the main method of the class.
	 *	The Function Object pattern matches many anonymous classes in
	 *	the JRE which implement an interface with a single method. These
	 *	are mostly event handlers, passed as callback hooks in GUI libraries
	 *	(AWT and Swing). Hence, such classes often realize the C O M -
	 *	M A N D design pattern.
	 */

	public boolean detect(final IEntity anEntity) {
		int nbMethod = 0;

		// Only a Class can be a Function Object
		if (anEntity instanceof IClass) {
			final Iterator iterator = anEntity.getIteratorOnActors();

			while (iterator.hasNext()) {
				final Object anOtherEntity = iterator.next();
				if (anOtherEntity instanceof IAbstractMethod) {
					final IAbstractMethod currentMethod =
						(IAbstractMethod) anOtherEntity;

					// Detect static attribute initialization
					if (!currentMethod.getName().equals("<clinit>")
						&& (!currentMethod.getID().startsWith("<init>"))) {

						nbMethod++;

						// The Methods must be "instance method" and public
						if ((currentMethod.isStatic())
							|| (!currentMethod.isPublic())) {
							return false;
						}
					}
				}

				// The Fields must be "instance field"
				if (anOtherEntity instanceof IField) {
					final IField currentField = (IField) anOtherEntity;
					if (currentField.isStatic()) {
						return false;
					}
				}
			}

			if (nbMethod == 1) {
				this.addEntities(anEntity);
				return true;
			}
			else {
				return false;
			}
		}
		return false;
	}
}

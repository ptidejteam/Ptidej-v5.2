package padl.analysis.micropattern.detection;

import java.util.Iterator;

import padl.analysis.micropattern.IMicroPatternDetection;
import padl.kernel.IClass;
import padl.kernel.IConstituent;
import padl.kernel.IEntity;
import padl.kernel.IInterface;
import padl.kernel.IMethod;

public class ExtenderDetection
	extends AbstractMicroPatternDetection
	implements IMicroPatternDetection {

	public String getName() {
		return "ExtenderDetection";
	}

	/*
	 *  27. Extender. An Extender is a class which extends the interface
	 *	inherited from its superclass and super interfaces, but does not over-
	 *	ride any method.
	 *	For example, class Properties (in java.util) extends its
	 *	superclass (Hashtable) by declaring several concrete methods,
	 *	which enrich the functionality provided to the client. None of these
	 *	methods overrides a previously implemented method, thus keeping
	 *	the superclass behavior intact. Note that an Extender may be re-
	 *	garded as an instantiation of a degenerate mixin class [8] over its
	 *	superclass.
	 */

	public boolean detect(final IEntity anEntity) {
		int nbMethod = 0;

		// Only Class can be Extender
		if (anEntity instanceof IClass) {

			final Iterator iterator = anEntity.getIteratorOnActors();
			while (iterator.hasNext()) {
				final Object anOtherEntity = iterator.next();

				if (anOtherEntity instanceof IMethod) {
					// Bypass constructor
					if (!((IMethod) anOtherEntity)
						.getID()
						.startsWith("<init>")) {
						nbMethod++;

						if (!checkInheritedTree(anEntity,
							(IMethod) anOtherEntity,
							true)) {
							return false;
						}
					}
				}
			}

			if (nbMethod > 0) {
				this.addEntities(anEntity);
				return true;
			}
		}
		return false;
	}

	private boolean checkInheritedTree(
		final IEntity anEntity,
		final IMethod currentMethod,
		final boolean rejectEmpty) {
		// All method must not be declared in the superClass/superInterface

		final Iterator InheritedActor =
			anEntity.listOfInheritedActors().iterator();

		if (rejectEmpty
			&& anEntity instanceof IInterface
			&& !InheritedActor.hasNext()) {
			return false;
		}

		while (InheritedActor.hasNext()) {
			final IConstituent aSuper = (IConstituent) InheritedActor.next();

			if (aSuper instanceof IClass || aSuper instanceof IInterface) {
				// Find the method in the superClass/superInterface
				final IMethod superClassMethod =
					(IMethod) ((IEntity) aSuper).getActorFromID(
						currentMethod.getID());

				// Must not be declared in the superClass/superInterface
				if (superClassMethod != null) {
					return false;
				}

				if (!checkInheritedTree((IEntity) aSuper,
					currentMethod,
					false)) {
					return false;
				}
			}
		}

		if (anEntity instanceof IClass) {
			final Iterator ImplementedActor =
				((IClass) anEntity).listOfImplementedActors().iterator();

			if (rejectEmpty && !ImplementedActor.hasNext())
				return false;

			while (ImplementedActor.hasNext()) {
				final IConstituent aSuper =
					(IConstituent) ImplementedActor.next();

				if (aSuper instanceof IClass
					|| aSuper instanceof IInterface) {
					// Find the method in the superClass/superInterface
					final IMethod superClassMethod =
						(IMethod) ((IEntity) aSuper).getActorFromID(
							currentMethod.getID());

					// Must not be declared in the superClass/superInterface
					if (superClassMethod != null) {
						return false;
					}

					if (!checkInheritedTree((IEntity) aSuper,
						currentMethod,
						false)) {
						return false;
					}
				}
			}
		}

		return true;
	}
}

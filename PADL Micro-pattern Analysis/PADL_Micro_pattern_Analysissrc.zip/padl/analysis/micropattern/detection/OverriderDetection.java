package padl.analysis.micropattern.detection;

import java.util.Iterator;

import padl.analysis.micropattern.IMicroPatternDetection;
import padl.kernel.IClass;
import padl.kernel.IEntity;
import padl.kernel.IMethod;

public class OverriderDetection
	extends AbstractMicroPatternDetection
	implements IMicroPatternDetection {

	public String getName() {
		return "OverriderDetection";
	}

	/*
	 *  26. Overrider. A class where each of its declared public methods
	 *	overrides a non-abstract method inherited from its superclass. Such
	 *	a class changes the behavior of its superclass while retaining its protocol.
	 *	A typical Overrider class is the BufferedOutputStream
	 *	class.
	 */

	public boolean detect(final IEntity anEntity) {
		// Must be a Class
		if (anEntity instanceof IClass) {

			final Iterator iterator = anEntity.getIteratorOnActors();
			while (iterator.hasNext()) {
				final Object anOtherEntity = iterator.next();

				if (anOtherEntity instanceof IMethod) {
					if (((IMethod) anOtherEntity).isPublic()
						&& !((IMethod) anOtherEntity).getID().startsWith(
							"<init>")) {

						// All public method must override a non-abstract method of the superclass
						final Iterator InheritedActor =
							anEntity.listOfInheritedActors().iterator();
						while (InheritedActor.hasNext()) {
							final IEntity aSuperClass =
								(IEntity) InheritedActor.next();

							// Find the method in the superclass
							final IMethod superClassMethod =
								(IMethod) aSuperClass.getActorFromID(
									((IMethod) anOtherEntity).getName()
										+ "()");

							// Must be declared in the superclass and abstract
							if (superClassMethod == null
								|| superClassMethod.isAbstract()) {
								return false;
							}
						}
					}
				}
			}

			this.addEntities(anEntity);
			return true;
		}
		return false;
	}
}

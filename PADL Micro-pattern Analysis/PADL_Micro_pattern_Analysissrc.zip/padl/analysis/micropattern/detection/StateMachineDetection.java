package padl.analysis.micropattern.detection;

import java.util.Iterator;

import padl.analysis.micropattern.IMicroPatternDetection;
import padl.kernel.IAbstractMethod;
import padl.kernel.IEntity;
import padl.kernel.IInterface;
import padl.kernel.IParameter;

public class StateMachineDetection
	extends AbstractMicroPatternDetection
	implements IMicroPatternDetection {

	public String getName() {
		return "StateMachineDetection";
	}

	/*
	 *  21. State Machine. It is not uncommon for an interface to define
	 *	only parameterless methods. Such an interface allows client code to
	 *	either query the state of the object, or, request the object to change
	 *	its state in some predefined manner. Since no parameters are passed,
	 *	the way the object changes is determined entirely by the object�s
	 *	dynamic type.
	 *	This sort of interface, captured by the State Machine pattern, is typical
	 *	for state machine classes.
	 *	For example, the interface java.util.Iterator describes the
	 *	protocol of the standard JAVA iterator, which is actually a state machine
	 *	that has two possible transitions: next() and remove().
	 *	The third method, hasNext() is a query that tests whether the
	 *	iteration is complete. In the state machine analogy, this query is
	 *	equivalent for checking if the machine�s final state was reached.
	 */

	public boolean detect(final IEntity anEntity) {
		// Must be an interface
		if (anEntity instanceof IInterface) {
			final Iterator iterator = anEntity.getIteratorOnActors();

			while (iterator.hasNext()) {
				final Object anOtherEntity = iterator.next();

				// Only method without parameter is allowed
				if (anOtherEntity instanceof IAbstractMethod) {
					final Iterator iter =
						(
							(
								IAbstractMethod) anOtherEntity)
									.getIteratorOnActors(
							IParameter.class);
					if (iter.hasNext()) {
						return false;
					}
				}
			}
			this.addEntities(anEntity);
			return true;
		}
		return false;
	}
}

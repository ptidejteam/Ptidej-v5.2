package padl.analysis.micropattern.detection;

import java.util.Iterator;

import padl.analysis.micropattern.IMicroPatternDetection;
import padl.kernel.IClass;
import padl.kernel.IEntity;
import padl.kernel.IMethod;
import padl.kernel.IMethodInvocation;

public class SinkDetection
	extends AbstractMicroPatternDetection
	implements IMicroPatternDetection {

	public String getName() {
		return "SinkDetection";
	}

	/*
	 *  18. Sink. A class where its declared methods do not call neither
	 *	instance methods nor static methods is a Sink.
	 *	Class JarEntry of package java.util.jar.JarEntry is
	 *	an example of Sink.
	 */

	public boolean detect(final IEntity anEntity) {
		// Only Class can be Sink
		if (anEntity instanceof IClass) {

			final Iterator iterator =
				anEntity.getIteratorOnActors(IMethod.class);
			while (iterator.hasNext()) {
				final Object anOtherEntity = iterator.next();
				final IMethod currentMethod = (IMethod) anOtherEntity;

				final Iterator invocation =
					currentMethod.getIteratorOnActors();
				while (invocation.hasNext()) {

					final Object currentItem = invocation.next();
					if (currentItem instanceof IMethodInvocation) {

						final IMethodInvocation currentInvocation =
							(IMethodInvocation) currentItem;
						if ((currentInvocation.getCalledMethod() != null)
							&& (!currentInvocation
								.getCalledMethod()
								.getName()
								.equals("="))) {

							return false;
						}
					}
				}
			}

			this.addEntities(anEntity);
			return true;
		}
		return false;
	}
}

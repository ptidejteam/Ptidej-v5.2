package padl.analysis.micropattern.detection;

import java.util.Iterator;

import padl.analysis.micropattern.IMicroPatternDetection;
import padl.kernel.IAbstractMethod;
import padl.kernel.IClass;
import padl.kernel.IEntity;
import padl.kernel.IField;

public class RecordDetection
	extends AbstractMicroPatternDetection
	implements IMicroPatternDetection {

	public String getName() {
		return "RecordDetection";
	}

	/*
	 *  16. Record. JAVA makes it possible to de�?ne classes which look
	 *	and feel much like PA S C A L [46] record types. A class matches
	 *	the Record micro pattern if all of its �?elds are public and if
	 *	has no methods other than constructors and methods inherited from
	 *	Object.
	 *	Perhaps surprisingly, there is a considerable number of examples
	 *	of this pattern in the JAVA standard library. For example, in pack-
	 *	age java.sql we �?nd class DriverPropertyInfo which is
	 *	a record managing a textual property passed to a JDBC driver.
	 */

	public boolean detect(final IEntity anEntity) {
		// Only Class can be Restricted Immutable
		if (anEntity instanceof IClass) {

			final Iterator iterator = anEntity.getIteratorOnActors();
			while (iterator.hasNext()) {
				final Object anOtherEntity = iterator.next();
				if (anOtherEntity instanceof IField) {
					// All Fields must be "public"
					final IField currentField = (IField) anOtherEntity;
					if (!currentField.isPublic()) {
						return false;
					}
				}

				if (anOtherEntity instanceof IAbstractMethod) {
					// Only method inherited from Object or constructor is allowed
					final IAbstractMethod currentMethod =
						(IAbstractMethod) anOtherEntity;

					// The method must be inherited from Object or a constructor
					final String methodName = currentMethod.getName();
					if (!((methodName.equals("clone"))
						|| (methodName.equals("equals"))
						|| (methodName.equals("finalize"))
						|| (methodName.equals("hashCode"))
						|| (methodName.equals("toString"))
						|| (currentMethod.getID().startsWith("<init>")))) {

						return false;
					}
				}
			}

			this.addEntities(anEntity);
			return true;
		}
		return false;
	}
}

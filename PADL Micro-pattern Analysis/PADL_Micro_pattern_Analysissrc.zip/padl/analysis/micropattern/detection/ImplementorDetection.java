package padl.analysis.micropattern.detection;

import java.util.Iterator;

import padl.analysis.micropattern.IMicroPatternDetection;
import padl.kernel.IClass;
import padl.kernel.IEntity;
import padl.kernel.IMethod;

public class ImplementorDetection
	extends AbstractMicroPatternDetection
	implements IMicroPatternDetection {

	public String getName() {
		return "ImplementorDetection";
	}

	/*
	 *  25. Implementor. An Implementor is a non-abstract class such that
	 *	all of its the public methods were declared as abstract in its superclass.
	 *	An example is class SimpleFormatter, which is defined in the
	 *	java.util.logging package). This class has single public
	 *	method,
	 *
	 *	format(LogRecord logrecord),
	 *
	 *	which was declared abstract by the superclass, Formatter (of the
	 *	same package).
	 */

	public boolean detect(final IEntity anEntity) {
		boolean bFound = false;

		// Must be a non-abstract Class
		if (!((IEntity) anEntity).isAbstract()) {

			final Iterator iterator = anEntity.getIteratorOnActors();
			while (iterator.hasNext()) {
				final Object anOtherEntity = iterator.next();

				if (anOtherEntity instanceof IMethod) {
					if (((IMethod) anOtherEntity).isPublic()
						&& !((IMethod) anOtherEntity).getID().startsWith(
							"<init>")) {

						// All public method need to be declared abstract in the superclass
						final Iterator InheritedActor =
							anEntity.listOfInheritedActors().iterator();

						while (InheritedActor.hasNext() && !bFound) {
							final IEntity aSuperClass =
								(IEntity) InheritedActor.next();

							// Find the method in the superclass
							final IMethod superClassMethod =
								(IMethod) aSuperClass.getActorFromID(
									((IMethod) anOtherEntity).getID());
							// Must be declared in the superclass and abstract
							if (superClassMethod != null
								&& superClassMethod.isAbstract()) {
								bFound = true;
							}
						}

						try {
							final Iterator InheritedActor2 =
								((IClass) anEntity)
									.listOfImplementedActors()
									.iterator();

							while (InheritedActor2.hasNext() && !bFound) {
								final IEntity aSuperClass =
									(IEntity) InheritedActor2.next();

								// Find the method in the superinterface
								final IMethod superClassMethod =
									(IMethod) aSuperClass.getActorFromID(
										((IMethod) anOtherEntity).getID());

								// Must be declared in the superclass and abstract
								if (superClassMethod != null
									&& superClassMethod.isAbstract()) {
									bFound = true;
								}
							}
						}
						catch (final Exception e) {
							// Nothing to do
						}

						if (!bFound) {
							return false;
						}
					}
				}
			}

			this.addEntities(anEntity);
			return true;
		}
		return false;
	}
}

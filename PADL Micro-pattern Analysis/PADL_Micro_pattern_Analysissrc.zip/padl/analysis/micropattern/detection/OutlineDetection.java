package padl.analysis.micropattern.detection;

import java.util.Iterator;

import padl.analysis.micropattern.IMicroPatternDetection;
import padl.kernel.IAbstractMethod;
import padl.kernel.IClass;
import padl.kernel.IConstituent;
import padl.kernel.IEntity;
import padl.kernel.IMethodInvocation;

public class OutlineDetection
	extends AbstractMicroPatternDetection
	implements IMicroPatternDetection {

	public String getName() {
		return "OutlineDetection";
	}

	/*
	 *  19. Outline. An Outline is an abstract class where two or more
	 *	declared methods invoke at least one abstract methods of the current
	 *	(�this�) object.
	 *	For example, the methods of java.io.Reader rely on the abstract
	 *	method
	 *	read(char ac[], int i, int j)
	 *	Obviously, Outline is related to the TEMPLATE METHOD design
	 *	pattern.
	 */

	public boolean detect(final IEntity anEntity) {
		int nbMethodCallingAbstractMethod = 0;

		// Must be an abstract Class
		if (anEntity instanceof IClass && anEntity.isAbstract()) {
			final Iterator iterator = anEntity.getIteratorOnActors();

			while (iterator.hasNext() && nbMethodCallingAbstractMethod < 2) {
				final Object anOtherEntity = iterator.next();

				if (anOtherEntity instanceof IAbstractMethod) {
					final IAbstractMethod currentMethod =
						(IAbstractMethod) anOtherEntity;

					// Check if this Method call other abstract 
					// Method of the current ("this") object.
					final Iterator invocation =
						currentMethod.getIteratorOnActors();
					while (invocation.hasNext()
						&& nbMethodCallingAbstractMethod < 2) {

						final Object currentItem = invocation.next();
						if (currentItem instanceof IMethodInvocation) {

							final IMethodInvocation currentInvocation =
								(IMethodInvocation) currentItem;
							if ((currentInvocation.getCalledMethod() != null)
								&& (!currentInvocation
									.getCalledMethod()
									.getName()
									.equals("="))
								&& (currentInvocation
									.getCalledMethod()
									.isAbstract())) {

								// Check if the abstract method belong to the current class.
								final IConstituent aConstituent =
									anEntity.getActorFromID(
										currentInvocation
											.getCalledMethod()
											.getID());
								if (aConstituent != null) {
									nbMethodCallingAbstractMethod++;
								}
							}
						}
					}
				}
			}

			if (nbMethodCallingAbstractMethod >= 2) {
				this.addEntities(anEntity);
				return true;
			}
			return false;
		}
		return false;
	}
}

package padl.analysis.micropattern.detection;

import java.util.HashSet;
import java.util.Set;

import padl.kernel.IEntity;

/**
 * @author tanterij
 */
class AbstractMicroPatternDetection {
	private Set entities = new HashSet();

	public void addEntities(final IEntity anEntity) {
		this.entities.add(anEntity);
	}
	public long getNumberOfEntities() {
		return this.entities.size();
	}
	public boolean detect(final IEntity anEntity) {
		/*
		 * Nothing to do, the detection class will do the job 
		 */
		return false;
	}
	public Set getEntities() {
		return this.entities;
	}
}

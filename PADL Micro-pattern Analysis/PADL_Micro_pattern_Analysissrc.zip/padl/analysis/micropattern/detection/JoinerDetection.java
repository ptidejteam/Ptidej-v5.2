package padl.analysis.micropattern.detection;

import java.util.Iterator;
import java.util.List;

import padl.analysis.micropattern.IMicroPatternDetection;
import padl.kernel.IAbstractMethod;
import padl.kernel.IClass;
import padl.kernel.IEntity;
import padl.kernel.IField;
import padl.kernel.IInterface;

public class JoinerDetection
	extends AbstractMicroPatternDetection
	implements IMicroPatternDetection {

	public String getName() {
		return "JoinerDetection";
	}

	/*
	 *	3. Joiner. An empty interface which extends more than one inter-
	 *	face is called a Joiner, since in effect, it joins together the sets of
	 *	members of its parents.
	 *	For example, the interface MouseInputListener joins together
	 *	two other interfaces: interface MouseMotionListener and in-
	 *	terface MouseListener.
	 *	An empty class which implements one or more interfaces is also
	 *	a Joiner. For example, class LinkedHashSet marries together
	 *	class HashSet and three interfaces Cloneable, Serializ-
	 *	able and Set.
	 *
	 */

	public boolean detect(final IEntity anEntity) {
		int numberOfInterface = 0;

		// Class and Interface can be a Joiner
		if ((anEntity instanceof IClass)
			|| (anEntity instanceof IInterface)) {
			final Iterator iterator = anEntity.getIteratorOnActors();

			while (iterator.hasNext()) {
				// No method allowed
				final Object anOtherEntity = iterator.next();
				if (anOtherEntity instanceof IAbstractMethod) {
					final IAbstractMethod currentMethod =
						(IAbstractMethod) anOtherEntity;
					// Detect static attribute initialization and constructor
					if (!currentMethod.getName().equals("<clinit>")
						&& (!currentMethod.getID().startsWith("<init>"))) {
						return false;
					}
				}
				// No attribute allowed
				if (anOtherEntity instanceof IField) {
					return false;
				}
			}

			// Looks good so far  :)
			// Count the number of implemented interface
			final List inheretedActor = anEntity.listOfInheritedActors();
			final Iterator myIterator = inheretedActor.iterator();
			while (myIterator.hasNext()) {
				final Object anOtherEntity = myIterator.next();
				if (anOtherEntity instanceof IInterface) {
					numberOfInterface++;
				}
			}

			if (anEntity instanceof IClass) {
				final List implementedActor =
					((IClass) anEntity).listOfImplementedActors();
				final Iterator mIterator = implementedActor.iterator();
				while (mIterator.hasNext()) {
					final Object anOtherEntity = mIterator.next();
					if (anOtherEntity instanceof IInterface) {
						numberOfInterface++;
					}
				}
			}

			if (numberOfInterface >= 2) {
				this.addEntities(anEntity);
				return true;
			}
		}
		return false;
	}
}

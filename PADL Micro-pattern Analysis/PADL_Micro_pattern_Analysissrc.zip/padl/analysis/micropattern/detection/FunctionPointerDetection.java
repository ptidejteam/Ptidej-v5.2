package padl.analysis.micropattern.detection;

import java.util.Iterator;

import padl.analysis.micropattern.IMicroPatternDetection;
import padl.kernel.IAbstractMethod;
import padl.kernel.IClass;
import padl.kernel.IEntity;
import padl.kernel.IField;

public class FunctionPointerDetection
	extends AbstractMicroPatternDetection
	implements IMicroPatternDetection {

	public String getName() {
		return "FunctionPointerDetection";
	}

	/*
	 * 	5. Function Pointer. Very peculiar are those classes which have no
	 *	�?elds at all, and only a single public instance method.
	 *	An example is class LdapNameParser (which is de�?ned in pack-
	 *	age com.sun.jndi.ldap.LdapNameParser). This class has
	 *	a single parse method, with (as expected) a string parameter.
	 *	Instances of Function Pointer classes represent the equivalent of a
	 *	function pointer (or a pointer to procedure) in the procedural pro-
	 *	gramming paradigm, or of a function value in the functional pro-
	 *	gramming paradigm. Such an instance can then be used to make
	 *	an indirect polymorphic call to this function. The task of function
	 *	composition (as in the functional programming paradigm), can be
	 *	achieved by using two such instances.
	 */

	public boolean detect(final IEntity anEntity) {
		int nbMethod = 0;

		// Only a Class can be a Function Pointer
		if (anEntity instanceof IClass) {
			final Iterator iterator = anEntity.getIteratorOnActors();

			while (iterator.hasNext()) {
				final Object anOtherEntity = iterator.next();
				if (anOtherEntity instanceof IAbstractMethod) {
					final IAbstractMethod currentMethod =
						(IAbstractMethod) anOtherEntity;

					// Detect static attribute initialization and constructor
					if (!currentMethod.getName().equals("<clinit>")
						&& (!currentMethod.getID().startsWith("<init>"))) {

						nbMethod++;

						// The Methods must be "instance method" and public
						if ((currentMethod.isStatic())
							|| (!currentMethod.isPublic())) {
							return false;
						}
					}
				}
				// No field allowed
				if (anOtherEntity instanceof IField) {
					return false;
				}
			}

			if (nbMethod == 1) {
				this.addEntities(anEntity);
				return true;
			}
			else {
				return false;
			}
		}
		return false;
	}
}

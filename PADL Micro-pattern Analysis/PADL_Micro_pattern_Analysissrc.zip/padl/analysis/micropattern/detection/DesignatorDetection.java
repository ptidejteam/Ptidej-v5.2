package padl.analysis.micropattern.detection;

import java.util.Iterator;
import java.util.List;

import padl.analysis.micropattern.IMicroPatternDetection;
import padl.kernel.IAbstractMethod;
import padl.kernel.IClass;
import padl.kernel.IEntity;
import padl.kernel.IField;
import padl.kernel.IGhost;
import padl.kernel.IInterface;

public class DesignatorDetection
	extends AbstractMicroPatternDetection
	implements IMicroPatternDetection {

	public String getName() {
		return "DesignatorDetection";
	}

	/*
	 *	1. Designator. The most trivial interface is an empty one. Interest-
	 *	ingly, vacuous interfaces are employed in a powerful programming
	 *	technique, of tagging classes in such a way that these tags can be
	 *	examined at runtime.
	 *	 
	 *	For example, a class that implements the empty interface Clone-
	 *	able indicates (at run time) that it is legal to make a �?eld-for-�?eld
	 *	copy of instances of that class.
	 *	Thus, a Designator micro pattern is an interface which does not de-
	 *	clare any methods, does not de�?ne any static �?elds or methods, and
	 *	does not inherit such members from any of its superinterfaces.
	 *	A class can also be Designator if its de�?nition, as well as the de�?n-
	 *	itions of all of its ancestors (other than Object), are empty.
	 *	Pattern Designator is the rarest, with only 0.2% prevalence in our
	 *	software corpus. It was included in the catalog because it presents
	 *	an important JAVA technique, which is also easily discernible.
	 */

	public boolean detect(final IEntity anEntity) {
		if ((anEntity instanceof IClass)
			|| (anEntity instanceof IInterface)) {

			if (!this.isEmpty(anEntity)) {
				return false;
			}

			if (!isInheritedActorsEmpty(anEntity)) {
				return false;
			}

			this.addEntities(anEntity);
			return true;
		}
		return false;
	}

	private boolean isInheritedActorsEmpty(IEntity anEntity) {
		// Looks good so far  :)
		final List inheretedActor = anEntity.listOfInheritedActors();
		final Iterator myIterator = inheretedActor.iterator();
		while (myIterator.hasNext()) {
			final Object anOtherEntity = myIterator.next();
			if (!(anOtherEntity instanceof IGhost)
				&& !((IEntity) anOtherEntity).getName().equals(
					"java.lang.Object")) {
				if (!this.isEmpty((IEntity) anOtherEntity)) {
					return false;
				}
			}
		}
		return true;
	}

	private boolean isEmpty(final IEntity anEntity) {
		final Iterator iterator = anEntity.getIteratorOnActors();

		while (iterator.hasNext()) {
			final Object anOtherEntity = iterator.next();
			if (anOtherEntity instanceof IAbstractMethod) {
				final IAbstractMethod currentMethod =
					(IAbstractMethod) anOtherEntity;

				// Detect static attribute initialization
				if (!currentMethod.getName().equals("<clinit>")) {
					return false;
				}
			}
			if (anOtherEntity instanceof IField) {
				return false;
			}
		}
		return true;
	}
}

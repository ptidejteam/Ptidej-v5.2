package padl.analysis.micropattern.detection;

import java.util.Iterator;

import padl.analysis.micropattern.IMicroPatternDetection;
import padl.kernel.IAbstractMethod;
import padl.kernel.IClass;
import padl.kernel.IEntity;
import padl.kernel.IField;

public class TraitDetection
	extends AbstractMicroPatternDetection
	implements IMicroPatternDetection {

	public String getName() {
		return "TraitDetection";
	}

	/*
	 *  20. Trait. The Trait pattern captures abstract classes which have no
	 *	state. Specifically, a Trait class must have no instance fields, and at
	 *	least one abstract method.
	 *	
	 *	The term Trait follows the traits modules of Sch�arli, Ducasse,
	 *	Nierstrasz and Black [38]. A trait module, found in e.g., the
	 *	SCALA [35] programming language, is a collection of implemented
	 *	methods, but with no underlying state.
	 *	
	 *	For instance, class Number (of package java.lang) provides an
	 *	implementation for two methods: shortValue() and for method
	 *	byteValue(). Other than this implementation, class Number
	 *	expects its subclass to provide the full state and complement the
	 *	implementation as necessary.
	 */

	public boolean detect(final IEntity anEntity) {
		int nbAbstractMethod = 0;

		// Must be an abstract Class
		if (anEntity instanceof IClass && anEntity.isAbstract()) {
			final Iterator iterator = anEntity.getIteratorOnActors();

			while (iterator.hasNext()) {
				final Object anOtherEntity = iterator.next();

				// No instance field allowed
				if (anOtherEntity instanceof IField
					&& !((IField) anOtherEntity).isStatic()) {
					return false;
				}

				// At least one abstract method
				if (anOtherEntity instanceof IAbstractMethod
					&& ((IAbstractMethod) anOtherEntity).isAbstract()) {
					nbAbstractMethod++;
				}
			}
			if (nbAbstractMethod >= 1) {
				this.addEntities(anEntity);
				return true;
			}
			return false;
		}
		return false;
	}
}

package padl.analysis.micropattern.detection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import padl.analysis.micropattern.IMicroPatternDetection;
import padl.kernel.IAbstractMethod;
import padl.kernel.IClass;
import padl.kernel.IEntity;
import padl.kernel.IField;
import padl.kernel.IMethod;
import padl.kernel.IMethodInvocation;

public class BoxDetection
	extends AbstractMicroPatternDetection
	implements IMicroPatternDetection {

	public String getName() {
		return "BoxDetection";
	}

	/*
	 * 	13. Box. A Box is class with exactly one instance �?eld. This in-
	 *	stance �?eld is mutated by at least one of the methods, or one of the
	 *	static methods, of the class.
	 *	Class CRC32 (in the java.util.crc package) is an example of
	 *	this micro pattern. Its entire state is represented by a single �?eld
	 *	(int crc), which is mutated by method
	 *	     update(int i)
	 */

	private List modifiedField = new ArrayList();

	public boolean detect(final IEntity anEntity) {
		int nbInstanceField = 0;

		// Only Class can be Restricted Creation
		if (anEntity instanceof IClass) {

			final Iterator iterator = anEntity.getIteratorOnActors();

			buildMethodModifiedFields(anEntity);

			while (iterator.hasNext() && nbInstanceField <= 1) {
				final Object anOtherEntity = iterator.next();

				// Only onw instance field allowed
				if (anOtherEntity instanceof IField) {
					if (!((IField) anOtherEntity).isStatic()) {
						nbInstanceField++;

						// This field must modified in one the method of the class
						if (!this.modifiedField.contains(anOtherEntity)) {
							return false;
						}
					}
				}
			}

			if (nbInstanceField == 1) {
				this.addEntities(anEntity);
				return true;
			}
			else
				return false;
		}
		return false;
	}

	public void buildMethodModifiedFields(final IEntity aClass) {
		this.modifiedField.clear();

		// Build list of modified field
		final Iterator iter = aClass.getIteratorOnActors();
		while (iter.hasNext()) {
			Object constituent = iter.next();
			if (constituent instanceof IMethod) {
				this.scanMethod((IMethod) constituent);
			}
		}
	}

	private void scanMethod(final IMethod aMethod) {
		// Check if the field is assign in this method
		final Iterator iterator = aMethod.getIteratorOnActors();
		while (iterator.hasNext()) {
			final Object entity = iterator.next();

			// Seach for MethodInvocation
			if (entity instanceof IMethodInvocation) {
				IMethodInvocation aMethodInvocation =
					(IMethodInvocation) entity;
				IAbstractMethod aCalledMethod =
					aMethodInvocation.getCalledMethod();
				if (aCalledMethod != null) {

					// Seach for variable assignation
					if (aCalledMethod.getName().equals("=")) {
						this.modifiedField.add(
							aMethodInvocation.getFirstCallingField());
					}
				}
			}
		}
	}

}

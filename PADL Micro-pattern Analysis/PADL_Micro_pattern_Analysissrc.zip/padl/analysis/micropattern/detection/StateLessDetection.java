package padl.analysis.micropattern.detection;

import java.util.Iterator;

import padl.analysis.micropattern.IMicroPatternDetection;
import padl.kernel.IClass;
import padl.kernel.IEntity;
import padl.kernel.IField;

public class StateLessDetection
	extends AbstractMicroPatternDetection
	implements IMicroPatternDetection {

	public String getName() {
		return "StateLessDetection";
	}

	/*
	 *  8. Stateless. If a class has no �?elds at all (except for �?elds which
	 *	are both static and final), then it is stateless. The behavior of
	 *	such a class cannot depend on its history. Therefore, the execution
	 *	of each of its methods can only be dictated by the parameters.
	 *	Micro pattern Stateless thus captures classes which are a named
	 *	collection of procedures, and is a representation, in the object-oriented
	 *	world, of a software library in the procedural programming para-
	 *	digm.
	 *	A famous example of the Stateless micro pattern is the Arrays
	 *	class, from package java.util.
	 */

	public boolean detect(final IEntity anEntity) {
		// Only class can be Stateless
		if (anEntity instanceof IClass) {
			final Iterator iterator =
				anEntity.getIteratorOnActors(IField.class);

			while (iterator.hasNext()) {
				final IField aField = (IField) iterator.next();

				// All field must be static and final
				if (!(aField.isStatic() && aField.isFinal())) {
					return false;
				}
			}
			this.addEntities(anEntity);
			return true;
		}
		return false;
	}
}

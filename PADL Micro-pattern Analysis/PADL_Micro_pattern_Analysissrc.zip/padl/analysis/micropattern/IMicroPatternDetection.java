package padl.analysis.micropattern;

import java.util.Set;

import padl.kernel.IEntity;

/**
 * @author tanterij
 */
public interface IMicroPatternDetection {
	public void addEntities(final IEntity anEntity);
	public long getNumberOfEntities();
	public Set getEntities();
	public boolean detect(final IEntity anEntity);
	public String getName();
}

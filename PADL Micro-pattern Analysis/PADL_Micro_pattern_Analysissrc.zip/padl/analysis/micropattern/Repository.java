/*
 * (c) Copyright 2000-2003 Yann-Ga�l Gu�h�neuc,
 * Ecole des Mines de Nantes and Object Technology International, Inc.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * Yann-Ga�l Gu�h�neuc, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
 * LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF YANN-GAEL GUEHENEUC IS ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.analysis.micropattern;

import java.security.AccessControlException;
import java.util.ArrayList;
import java.util.List;

import padl.IFileRepository;
import padl.util.DefaultFileRepository;
import util.PropertyManager;
import util.io.SubtypeLoader;
import util.multilingual.MultilingualManager;

import com.ibm.toad.cfparse.ClassFile;

/**
 * @author Yann-Ga�l Gu�h�neuc
 * @since  2007/02/13
 */
public class Repository {
	private static Repository UniqueInstance;

	public static Repository getInstance(final IFileRepository fileRepository) {
		if (Repository.UniqueInstance == null) {
			Repository.UniqueInstance =
				new Repository(fileRepository);
		}
		return Repository.UniqueInstance;
	}
	public static void main(final String args[]) {
		final Repository repository =
			Repository.getInstance(
				new DefaultFileRepository(
					Repository.class));
		System.out.println(repository.toString());
	}

	private IMicroPatternDetection[] detections;
	private Repository(final IFileRepository fileRepository) {
		// Yann 2003/10/14: Demo!
		// I must catch the AccessControlException
		// thrown when attempting loading analyses
		// from the applet viewer.
		try {
			final ClassFile[] classFiles =
				SubtypeLoader.loadSubtypesFromStream(
					PropertyManager.getMicroPatternDetectionType(),
					fileRepository.getFiles(),
					PropertyManager.getMicroPatternDetectionPackage(),
					PropertyManager.getMicroPatternDetectionExtension());
			final List listOfDetections = new ArrayList(classFiles.length);
			for (int i = 0; i < classFiles.length; i++) {
				try {
					listOfDetections.add(
						(IMicroPatternDetection) Class
							.forName(classFiles[i].getName())
							.newInstance());
				}
				// Yann 2003/10/07: Protection!
				// I want to make sure that any problem in this
				// section won't break the program...
				//	catch (final ClassNotFoundException cnfe) {
				//		// cnfe.printStackTrace();
				//	}
				//	catch (final InstantiationException ie) {
				//		// ie.printStackTrace();
				//	}
				//	catch (final IllegalAccessException iae) {
				//		// iae.printStackTrace();
				//	}
				//	catch (final NoClassDefFoundError ncdfe) {
				catch (final Throwable t) {
					System.err.println(
						MultilingualManager.getString(
							"LOAD_ANALYSIS",
							Repository.class,
							new Object[] {
								classFiles[i].getName(),
								t.getMessage()}));
				}
			}

			this.detections =
				new IMicroPatternDetection[listOfDetections.size()];
			listOfDetections.toArray(this.detections);
		}
		catch (final AccessControlException ace) {
			this.detections = new IMicroPatternDetection[0];
		}
	}
	public IMicroPatternDetection[] listOfMicroPatternDetections() {
		return this.detections;
	}
	public String toString() {
		final StringBuffer buffer = new StringBuffer();
		buffer.append("Micro-pattern Detection Repository:\n");
		for (int x = 0; x < this.listOfMicroPatternDetections().length; x++) {
			buffer.append('\t');
			buffer.append(this.listOfMicroPatternDetections()[x].getName());
			buffer.append('\n');
		}
		return buffer.toString();
	}
}

/*
 * (c) Copyright 2001-2004 Yann-Ga�l Gu�h�neuc,
 * University of Montr�al.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the author, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN,
 * ANY LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHOR IS ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.creator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import padl.event.IModelListener;
import padl.kernel.IAbstractLevelModel;
import padl.kernel.ICodeLevelModel;
import padl.kernel.ICodeLevelModelCreator;
import padl.kernel.IConstituent;
import padl.kernel.IIdiomLevelModel;
import padl.kernel.exception.ModelDeclarationException;
import padl.kernel.impl.Factory;
import util.io.Output;
import util.multilingual.MultilingualManager;

/**
 * @author Yann-Ga�l Gu�h�neuc
 * @since  2004/02/20
 */
public class AOLCreator implements ICodeLevelModelCreator {
	private static final int AOL_CODE = 0;
	private static final int AOL_IDIOM = 1;

	private static String computeFilteredFileName(final String aFileName) {
		return aFileName.substring(0, aFileName.indexOf(".aol"))
			+ ".filtered.aol";
	}

	private String fileName;
	public AOLCreator(final String[] fileNames) {
		// TODO: Must deal with multiple AOL files!
		this.fileName = fileNames[0];
	}
	public void create(final ICodeLevelModel aCodeLevelModel) {
		this.create(aCodeLevelModel, false);
	}
	public void create(
		final ICodeLevelModel aCodeLevelModel,
		final boolean forceFiltering) {

		this.create(aCodeLevelModel, forceFiltering, true);
	}
	public void create(
		final ICodeLevelModel aCodeLevelModel,
		final boolean forceFiltering,
		final boolean enableSemanticActions) {

		try {
			this.filter(forceFiltering);
			final ICodeLevelModel codeLevelModel =
				(ICodeLevelModel) this.parse(
					enableSemanticActions,
					AOLCreator.AOL_CODE);

			//	System.out.println(idiomLevelModel);
			this.updateModel(aCodeLevelModel, codeLevelModel);
		}
		catch (final Exception e) {
			e.printStackTrace(Output.getInstance().errorOutput());
		}
	}
	public void create(
		final IIdiomLevelModel aIdiomLevelModel,
		final boolean forceFiltering,
		final boolean enableSemanticActions) {

		try {
			this.filter(forceFiltering);
			final IIdiomLevelModel designLevelModel =
				(IIdiomLevelModel) this.parse(
					enableSemanticActions,
					AOLCreator.AOL_IDIOM);

			//	System.out.println(idiomLevelModel);
			this.updateModel(aIdiomLevelModel, designLevelModel);
		}
		catch (final Exception e) {
			e.printStackTrace(Output.getInstance().errorOutput());
		}
	}
	private void updateModel(
		final IAbstractLevelModel originModel,
		final IAbstractLevelModel destination) {

		// Yann 2004/12/14: Listeners... again!
		// Once the idiom-level model is built by the parser, I copy
		// all the entities in the given idiom-level model (from the
		// arguments). Thus, I count twice every entities! (Once at
		// creation/addition time, second at copy time.) To solve
		// this problem, I remove temporarily all listeners before
		// copying and then add them back.

		final List currentListeners = originModel.getModelListeners();
		final int numberOfCurrentListeners = currentListeners.size() - 1;
		final List formerListeners = new ArrayList();
		for (int i = numberOfCurrentListeners; i >= 0; i--) {
			final IModelListener listener =
				(IModelListener) currentListeners.get(i);
			formerListeners.add(listener);
			originModel.removeModelListener(listener);
		}

		final Iterator iterator = destination.getIteratorOnActors();
		while (iterator.hasNext()) {
			try {
				originModel.addActor((IConstituent) iterator.next());
			}
			catch (final ModelDeclarationException e) {
				e.printStackTrace(Output.getInstance().errorOutput());
			}
		}

		originModel.addModelListeners(formerListeners);
	}
	private void filter(final boolean forceFiltering) {
		if (forceFiltering
			|| !new File(AOLCreator.computeFilteredFileName(this.fileName))
				.exists()) {

			System.out.println("Filtering...");

			try {
				final LineNumberReader reader =
					new LineNumberReader(
						new InputStreamReader(
							new FileInputStream(this.fileName)));
				final StringBuffer buffer = new StringBuffer();
				String readLine;
				while ((readLine = reader.readLine()) != null) {
					buffer.append(readLine);
					buffer.append('\n');
				}
				reader.close();

				// See line 81 of the original Sodali's ADM.aol file.
				this.replace(buffer, "operator =", "operator=");

				// See line 175 of the original Sodali's ADM.aol file.
				this.replace(buffer, "consts", "const");

				// See line 187 of the original Sodali's ADM.aol file.
				this.replace(buffer, " ~ ", " ~");

				// See line 567 of the original Sodali's ADM.aol file.
				this.replace(buffer, " One", " ONE");

				// See line 584 of the original Sodali's ADM.aol file.
				this.replace(
					buffer,
					"CLASS ADM_ProfileDomain MULT ONE",
					"CLASS ADM_ProfileDomain MULT ONE;");

				// See line 584 of the original Sodali's ADM.aol file.
				this.replace(buffer, "NAMEe`_eseguito_da", "");

				// See line 584 of the original Sodali's ADM.aol file.
				this.replace(buffer, "NAMEesegue", "");

				// See line 698 of the original Sodali's ADM.aol file.
				this.replace(buffer, "e`attivatoda", "activation");

				// See line 698 of the original Sodali's ADM.aol file.
				this.replace(buffer, "appartengonoa", "aggregation");

				// See line 698 of the original Sodali's ADM.aol file.
				this.replace(buffer, "e`compostada", "composition");

				// See line 698 of the original Sodali's ADM.aol file.
				this.replace(
					buffer,
					"e`abilitata/disabilitatada",
					"activation");

				// See line 698 of the original Sodali's ADM.aol file.
				this.replace(
					buffer,
					"persistentdata(storing/retrieving)",
					"serialisation");

				// See line 698 of the original Sodali's ADM.aol file.
				this.replace(
					buffer,
					"persistentdata(storing/retriving)",
					"serialisation");

				// See line 788 of the original Sodali's ADM.aol file.
				this.replace(buffer, "ONE;,", "ONE,");

				// See line 16 of the original Sodali's DB.aol file.
				this.replace(buffer, "+$", "$+");

				// See line 97 of the original Sodali's DB.aol file.
				this.replace(buffer, " = \"\"", "");

				// See line 170 of the original Sodali's DB.aol file.
				this.replace(buffer, " & ", " &");

				// See line 258 of the original Sodali's DB.aol file.
				this.replace(buffer, "List <IMS_Id>", "List<IMS_Id>");

				// See line 473 of the original Sodali's DB.aol file.
				this.replace(
					buffer,
					"CLASS DB_ADM_FaultData\tMULT ONE",
					"CLASS DB_ADM_FaultData MULT ONE;");

				// See line 474 of the original Sodali's DB.aol file.
				this.replace(buffer, "NAMEn", "");

				// See line 478 of the original Sodali's DB.aol file.
				this.replace(buffer, "NAMEParent", "");

				// See line 478 of the original Sodali's DB.aol file.
				this.replace(buffer, "NAMEChildren", "");

				// See line 50 of the original Sodali's GUI.aol file.
				this.replace(buffer, "static init(", "init(");

				// See line 72 of the original Sodali's GUI.aol file.
				this.replace(buffer, " virtual ", " ");

				// See line 215 of the original Sodali's GUI.aol file.
				this.replace(
					buffer,
					"asKey : RWCString(): ,",
					"asKey():RWCString,");

				// See line 216 of the original Sodali's GUI.aol file.
				this.replace(
					buffer,
					"asText : RWCString(): ,",
					"asText():RWCString,");

				// See line 306 of the original Sodali's GUI.aol file.
				this.replace(
					buffer,
					"List <CmgOvwObject>",
					"List<CmgOvwObject>");

				// See line 306 of the original Sodali's GUI.aol file.
				this.replace(
					buffer,
					"&selections int argc,",
					"&selections, int argc,");

				// See line 484 of the original Sodali's GUI.aol file.
				this.replace(
					buffer,
					"AlbAttrVarEnum::type",
					"AlbAttrVarEnum_type");

				// See line 1018 of the original Sodali's GUI.aol file.
				this.replace(
					buffer,
					"CLASS MM_ObjectAckRec\tMULT ONE",
					"CLASS MM_ObjectAckRec MULT ONE;");

				// See line 1239 of the original Sodali's GUI.aol file.
				this.replace(buffer, "ONE;,", "ONE,");

				// See line 96 of the original Sodali's NMI.aol file.
				this.replace(
					buffer,
					"CORBA::SystemException",
					"CORBA_SystemException");

				// See line 359 of the original Sodali's TM.aol file.
				this.replace(buffer, "NAME child", "");

				// See line 361 of the original Sodali's TM.aol file.
				this.replace(buffer, "NAME parent", "");

				// See line 361 of the original Sodali's TM.aol file.
				this.replace(
					buffer,
					"CLASS TM_MsgVnmFIFO\tMULT ONE",
					"CLASS TM_MsgVnmFIFO MULT ONE;");

				// See line 295 of the original Sodali's TM.aol file.
				this.replace(buffer, "ONE;;", "ONE;");

				// See line 348 of the original Sodali's TM.aol file.
				this.replace(buffer, "ONE;,", "ONE,");

				// See line 348 of the original Sodali's TM.aol file.
				this.replace(buffer, "int; ", "int ");

				// See line 336 of the original Sodali's TM.aol file.
				this.replace(
					buffer,
					"MULT ONE\n RELATION",
					"MULT ONE;\n RELATION");

				// See line 359 of the original Sodali's TM.aol file.
				this.replace(buffer, "NAMEchild", "");

				// See line 360 of the original Sodali's TM.aol file.
				this.replace(buffer, "NAMEparent", "");

				// See line 1 of the original Sodali's TM.aol file.
				this.replace(buffer, " CLASS", "CLASS");

				// See line 48875 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(
					buffer,
					" struct {\n                int hits[GC_CACHE_SIZE];\n                int misses;\n                int reclaim;\n               } GCCacheStats;",
					"");

				// See line 97071 of the original mozilla-1.1-concat_des_2006-02-14082728.aol file.
				this.replace(
					buffer,
					" struct { \n                int hits[GC_CACHE_SIZE];\n                int misses;\n                int reclaim;\n               } GCCacheStats;",
					"");

				// See line 238085 of the original mozilla-1.1-concat_des_2006-02-14082728.aol file.
				this.replace(
					buffer,
					"CONST_nsstype\n  nsstype *&object;                                \\\npublic:                                            \\\n  nsstype\n    :object {  }                           \\\n  ~nsstype\n    if  {                                   \\\n      cleanfunc;                           \\\n      object",
					"");

				// See line 68161 of the original mozilla-1.2-concat_des_2006-02-13180947.aol file.
				this.replace(buffer, "%get()->", "");

				// See line 123869 of the original mozilla-1.2-concat_des_2006-02-13180947.aol file.
				this.replace(buffer, "n, n* or n%", "");

				// See line 24363 of the original mozilla-1.2-concat_des_2006-02-13180947.aol file.
				this.replace(buffer, ":CLASSNAME~CLASSNAME", "BOOO");

				// See line 24353 of the original mozilla-1.2-concat_des_2006-02-13180947.aol file.
				this.replace(buffer, "CLASSNAME:BOOO", "BOOO");

				// See line 24358 of the original mozilla-1.2-concat_des_2006-02-13180947.aol file.
				this.replace(buffer, "CLASSNAME", "BOOO");

				// See line 107174 of the original mozilla-1.1-concat_des_2006-02-14082728.aol file.
				this.replace(buffer, "meant to be\n   * overridden", "");

				// See line 162533 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, "for HTML or XML", "");

				// See line 171680 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, "/*out* ", "");

				// See line 179417 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, "__RPC_FAR *__RPC_FAR ", "");

				// See line 179417 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, "__RPC_FAR ", "");

				// See line 26371 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, "QueuedFileData *", "QueuedFileData*");

				// See line 190240 of the original mozilla-1.4-concat_des_2006-02-14072834.aol file.
				this.replace(buffer, ", class ns", ", ns");

				// See line 103613 of the original mozilla-1.4-concat_des_2006-02-14072834.aol file.
				this.replace(
					buffer,
					"\n                            GetStyleData(eStyleStruct_\n     }",
					"");

				// See line 42846 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(
					buffer,
					"        PRIVATE operator_=(CONST_nsstype\n  nsstype *&object;                                \\\npublic:                                            \\\n  nsstype\n    :object {  }                           \\\n  ~nsstype\n    if  {                                   \\\n      cleanfunc;                           \\\n      object):\\ \\ nsstype nsstype void\n",
					"");

				// See line 143468 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(
					buffer,
					"/ *0: not locked *-1: a native lockfile call is in progress *> 0: ",
					"");

				// See line 79623 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(
					buffer,
					"_CONTAINER CLASS ",
					"_ CONTAINER CLASS ");

				// See line 80197 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(
					buffer,
					"PUBLIC _size_map[WORDS_TO_BYTES(MAXOBJSZ+1):unsigned,\n",
					"");

				// See line 80197 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(
					buffer,
					"PUBLIC _modws_valid_offsets[sizeof(word):char\n",
					"");

				// See line 80197 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(
					buffer,
					"PUBLIC (()[BYTES_TO_WORDS]):BOOO,\n",
					"");

				// See line 146328 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(
					buffer,
					"(full text and pos vs. cutted text and col0, glphyTextLen vs. replaceBefore/-After):/** <em>Note< m>: I use different strategies to pass context between the,\n",
					"():void,\n");

				// See line 58991 of the original mozilla-1.7-concat_des_2006-02-16032602.aol file.
				this.replace(buffer, "PRIVATE !(defined && defined):!,", "");

				// See line 58679 of the original mozilla-1.7b-concat_des_2006-02-13183827.aol file.
				this.replace(
					buffer,
					"PRIVATE (!defined || __GNUC__ > 2 || __GNUC_MINOR__ > 95):BOOO,",
					"");

				// See line 238991 of the original mozilla-1.7-concat_des_2006-02-16032602.aol file.
				this.replace(
					buffer,
					"classnsUnicodeToUTF16:nsUnicodeToUTF16BE",
					"");

				// See line 505 of the original DB_2.1.2.N.aol file.
				this.replace(
					buffer,
					":_Error_, List<VNM_Id> & idVNMNWObjectList)",
					"");

				// See line 656 of the original DB_2.1.2.N.aol file.
				this.replace(
					buffer,
					"PUBLIC loadConnectedObjectIdList(void):_Error_, List<PointToPointItem> & connectedIdList):_Error_,",
					"PUBLIC loadConnectedObjectIdList(List<PointToPointItem> & connectedIdList):_Error_,");

				// See line 691 of the original NMI_2.2.0.N.aol file.
				this.replace(
					buffer,
					"PUBLIC info2(the default level):void,",
					"PUBLIC info2():void,");

				// See line 1936 of the original AlarmBrowser.aol.raw file.
				this.replace(buffer, "int atPosition = -1", "int atPosition");

				// See line 2086 of the original AlarmBrowser.aol.raw file.
				this.replace(buffer, "row = XTBL_ALL_TABLE", "row");

				// See line 3487 of the original AlarmBrowser.aol.raw file.
				this.replace(
					buffer,
					"RWBoolean waitOnLock = TRUE",
					"RWBoolean waitOnLock");

				// See line 237 of the original DbConn.aol.raw file.
				this.replace(
					buffer,
					"sqlBoolean_t bAutoMessagesHandler = SQL_TRUE",
					"sqlBoolean_t bAutoMessagesHandler");

				// See line 223 of the original VSPA_Processing.aol.raw file.
				this.replace(
					buffer,
					"int iCallerIsValidation = 1",
					"int iCallerIsValidation");

				// See line 81 of the original CollectorAcquisition.aol.raw file.
				this.replace(buffer, "int mode = 2", "int mode");

				// See line 17 of the original CollectorDistribution.aol.raw file.
				this.replace(
					buffer,
					"int entryType = DIRS | REG_FILES | LINKS",
					"int entryType");

				// See line 2735 of the original AlarmBrowser.aol.raw file.
				this.replace(
					buffer,
					"const AlbSortingCriteria",
					"AlbSortingCriteria");

				// See line 3760 of the original AlarmBrowser.aol.raw file.
				this.replace(buffer, "const AlbFilterBase", "AlbFilterBase");

				// See line 1937 of the original AlarmBrowser.aol.raw file.
				this.replace(buffer, "(T* * , T* *)", "a");

				// See line 235 of the original LOGLIB.aol.raw file.
				this.replace(
					buffer,
					"cfgFile class LogCfgFile : public Config",
					"Config");

				// See line 78 of the original Error_Library.aol.raw file.
				this.replace(buffer, "RC_class:const", "rcc:RC_class");

				// See line 146328 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, "GENERALIZATIONS", "GENERALIZATION");

				// See line 89636 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, "_MULT ", "_ MULT ");

				// See line 146328 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, "unisgned", "unsigned");

				// See line 144343 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, "long long ", "long ");

				// See line 73486 of the original mozilla-1.2-concat_des_2006-02-13180947.aol file.
				this.replace(buffer, " long long,", " long,");

				// See line 73486 of the original mozilla-1.2-concat_des_2006-02-13180947.aol file.
				this.replace(buffer, " long long\n", " long\n");

				// See line 800 of the original ddd.raw.aol file.
				this.replace(buffer, ":public:", ":");

				// See line 31063 of the original mozilla-1.5-concat_des_2006-02-13183653.aol file.
				this.replace(buffer, " public: ", " ");

				// See line 23120 of the original ddd.raw.aol file.
				this.replace(buffer, ":protected:", ":");

				// See line 59133 of the original mozilla-1.6-concat_des_2006-02-14215550.aol file.
				this.replace(buffer, " protected: ", " ");

				// See line 144343 of the original mozilla-1.1-concat_des_2006-02-14082728.aol file.
				this.replace(buffer, " = 0", "");

				// See line 1441 of the original ddd.raw.aol file.
				this.replace(buffer, ":,", ",");

				// See lines 904, 2697 of the original ddd.raw.aol file.
				this.replace(buffer, "* *", "*");
				this.replace(buffer, "& *", "*");

				// See line 2274 of the original ddd.raw.aol file.
				this.replace(buffer, "* operator", "*");

				// See line 4864 of the original ddd.raw.aol file.
				this.replace(buffer, ":inline", ":");

				// See line 712 of the original moz-1.0.rel.n.aol file.
				this.replace(buffer, " & ", "& ");

				// See line 1208 of the original moz-1.0.rel.n.aol file.
				this.replace(buffer, ":friend ", ": ");

				// See line 1399 of the original moz-1.0.rel.n.aol file.
				this.replace(buffer, " * ", "* ");

				// See line 4241 of the original moz-1.0.rel.n.aol file.
				this.replace(buffer, " struct ", " ");

				// See line 95 of the original DistPublic.aol.raw file.
				this.replace(buffer, "struct tm ", " tm ");

				// See line 19783 of the original moz-1.0.rel.n.aol file.
				this.replace(buffer, ":struct ", ": ");

				// See line 18918 of the original moz-1.0.rel.n.aol file.
				this.replace(buffer, " *& ", "* ");

				// See line 28646 of the original moz-1.0.rel.n.aol file.
				this.replace(buffer, " ** ", "** ");

				// See line 1320 of the original Admin_2.3.3.N.aol file.
				this.replace(buffer, ":const ", ":");

				// See line 70 of the original Admin_2.3.3.N.aol file.
				this.replace(buffer, "char* const", "char*");

				// See line 647 of the original moz-1.0.rel.n.aol file.
				this.replace(buffer, " const ,", ",");

				// See line 28412 of the original ddd.raw.aol file.
				this.replace(buffer, " const*& ", " ");

				// See line 31402 of the original mozilla-1.2-concat_des_2006-02-13180947.aol file.
				this.replace(buffer, " const& ", " ");

				// See line 29247 of the original ddd.raw.aol file.
				this.replace(buffer, " const* ", " ");

				// See line 48356 of the original moz-1.0.rel.n.aol file.
				this.replace(buffer, " const ", "");

				// See line 49728 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, " const\n", "");

				// See line 49168 of the original moz-1.0.rel.n.aol file.
				this.replace(buffer, " const,", ",");

				// See line 31402 of the original mozilla-1.2-concat_des_2006-02-13180947.aol file.
				this.replace(buffer, "_XCONST_unsigned ", "unsigned ");

				// See line 44163 of the original mozilla-1.2-concat_des_2006-02-13180947.aol file.
				this.replace(buffer, "CONST_unsigned ", "unsigned ");

				// See line 88774 of the original moz-1.0.rel.n.aol file.
				this.replace(buffer, "CONST_struct ", "CONST_");

				// See line 148150 of the original moz-1.0.rel.n.aol file.
				this.replace(buffer, "CONST_typename ", "CONST_");

				// See line 31087 of the original ddd.raw.aol file.
				this.replace(buffer, ": inline ", ":");

				// See line 46198 of the original ddd.raw.aol file.
				this.replace(buffer, "(struct ", "(");

				// See line 91661 of the original ddd.raw.aol file.
				this.replace(buffer, ":private:", ":");

				// See line 181502 of the original ddd.raw.aol file.
				this.replace(buffer, "(class ", "(");

				// See line 192802 of the original ddd.raw.aol file.
				this.replace(buffer, "__inline__ ", "");

				// See line 237853 of the original moz-1.0.rel.n.aol file.
				this.replace(buffer, " enum ", "");

				// See line 237853 of the original moz-1.0.rel.n.aol file.
				this.replace(buffer, "enum ", "");

				// See line 41 of the original ConfigLib file.
				this.replace(buffer, "CONTAINERCLASS ", "CONTAINER CLASS ");

				// See line 141 of the original Error_Library file.
				this.replace(buffer, "CLASSCLASS_NAME", "CLASS CLASS_NAME");

				// See line 141 of the original Error_Library file.
				this.replace(
					buffer,
					"SUBCLASSESCLASS_NAME",
					"SUBCLASSES CLASS_NAME");

				// See line 141 of the original Error_Library file.
				this.replace(buffer, "tm tm", "tm_tm");

				// See line 141 of the original Error_Library file.
				this.replace(
					buffer,
					"RegElement\tMULT ONE",
					"RegElement MULT ONE;");

				// See line 141 of the original Error_Library file.
				this.replace(buffer, "void* () pFunc", "void* pFunc");

				// See line 141 of the original Error_Library file.
				this.replace(
					buffer,
					"IMS_Trap\tMULT ONE\n",
					"IMS_Trap MULT ONE;");

				// See line 141 of the original Error_Library file.
				this.replace(
					buffer,
					"_Error_\tMULT ONE\n",
					"_Error_ MULT ONE;");

				// See line 141 of the original Error_Library file.
				this.replace(buffer, "; : ", " : ");

				// See line 141 of the original Error_Library file.
				this.replace(buffer, "&cfgVER'", "&cfgVER,");

				// See line 141 of the original Error_Library file.
				this.replace(buffer, "unsigned int to", "unsigned int");

				// See line 141 of the original Error_Library file.
				this.replace(
					buffer,
					"CLASS Binding\tMULT ONE\n",
					"CLASS Binding MULT ONE;\n");

				// See line 141 of the original Error_Library file.
				this.replace(
					buffer,
					"sServerName char*",
					"sServerName, char*");

				// See line 141 of the original Error_Library file.
				this.replace(
					buffer,
					"CLASS Vbs_VmcsServerThread\tMULT ONE",
					"CLASS Vbs_VmcsServerThread MULT ONE;");

				// See line 141 of the original Error_Library file.
				this.replace(
					buffer,
					"GENERALIZATION cfgFileclassLogCfgFile:Config",
					"GENERALIZATION Config");

				// See line 141 of the original Error_Library file.
				this.replace(buffer, " = 1", "");

				// See line 141 of the original Error_Library file.
				this.replace(buffer, "const unsigned int", "const int");

				// See line 141 of the original Error_Library file.
				this.replace(
					buffer,
					"*puiStartTime unsigned",
					"*puiStartTime, unsigned");

				// See line 141 of the original Error_Library file.
				this.replace(buffer, "Many", "MANY");

				// See line 141 of the original Error_Library file.
				this.replace(
					buffer,
					"Vbs_tblFileStus   MULT ONE\n",
					"Vbs_tblFileStus\tMULT ONE;\n");

				// See line 141 of the original Error_Library file.
				this.replace(buffer, "MULT 1", "MULT ONE");

				// See line 141 of the original Error_Library file.
				this.replace(buffer, "QUALIFIER uiPortNumber", "");

				// See line 141 of the original Error_Library file.
				this.replace(
					buffer,
					"VP_FM_TableElement\tMULT MANY",
					"VP_FM_TableElement MULT MANY;");

				// See line 141 of the original Error_Library file.
				this.replace(
					buffer,
					"        List<VNM_Id>& idVNMNWObjectList):_Error_,",
					"");

				// See line 141 of the original Error_Library file.
				this.replace(
					buffer,
					"       List<PointToPointItem> &connectedIdList):_Error_,",
					"");

				// See line 141 of the original Error_Library file.
				this.replace(buffer, "rcs9[64 -", "");

				// See line 141 of the original Error_Library file.
				this.replace(
					buffer,
					"ThreadObjectclassNotifyServerInterface:Interface",
					"ThreadObjectclassNotifyServerInterface");

				// See line 141 of the original Error_Library file.
				this.replace(
					buffer,
					"ThreadObjectclassRPCServerInterface:Interface",
					"ThreadObjectclassRPCServerInterface");

				// See line 141 of the original Error_Library file.
				this.replace(buffer, " = FALSE", "");

				// See line 141 of the original Error_Library file.
				this.replace(buffer, " = Open", "");

				// See line 141 of the original Error_Library file.
				this.replace(
					buffer,
					"AttributeState::AlarmState st, AttributeSeverity::AlarmSeverity sev,",
					"AlarmState st, AlarmSeverity sev,");

				// See line 141 of the original Error_Library file.
				this.replace(buffer, " = true", "");

				// See line 141 of the original Error_Library file.
				this.replace(buffer, " = TRUE", "");

				// See line 141 of the original Error_Library file.
				this.replace(
					buffer,
					"CLASS AttributeCriteriaBase\tMULT MANY\n",
					"CLASS AttributeCriteriaBase MULT MANY;\n");

				// See line 141 of the original Error_Library file.
				this.replace(buffer, "MULT 2", "MULT MANY");

				// See line 141 of the original Error_Library file.
				this.replace(buffer, "MULT ExactlyOne", "MULT ONE");

				// See line 141 of the original Error_Library file.
				this.replace(
					buffer,
					"CLASS Vbs_tblFileStus\tMULT ONE\n",
					"CLASS Vbs_tblFileStus MULT ONE;\n");

				// See line 141 of the original Error_Library file.
				this.replace(
					buffer,
					"AGGREGATION TypeList CONTAINER",
					"AGGREGATION NAME TypeList CONTAINER");

				// See line 177 of the original access_bkmkd_page.0.aol file.
				this.replace(buffer, ":,", ":void,");

				// See line 2539 of the original access_bkmkd_page.0.aol file.
				this.replace(buffer, ":\n", ":void\n");

				// See line 20342 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, ":\\,\n", ":void,\n");

				// See line 112958 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, ":\\\n", ":void\n");

				// See line 27748 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, ":\\ \\,\n", ":void,\n");

				// See line 48875 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, ",)", ")");

				// See line 48875 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, "():, ", "(");

				// See line 65579 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, "FAR* ", "");

				// See line 50220 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, "):, ", "");

				// See line 86706 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, ":\\ \\\n", ":void\n");

				// See line 86706 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, " ()():", " dummy():");

				// See line 104868 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, "%* ", "%*");

				// See line 112955 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, ":\\ \\ \\,\n", ":void,\n");

				// See line 112959 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, ":\\\n", ":\\\n");

				// See line 146328 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, "'", "");

				// See line 49317 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				this.replace(buffer, ":/*,\n", ":void,\n");

				// See line 50220 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				// See line 79929 of the original mozilla-1.0-concat_des_2006-02-15114305.aol file.
				int pos = 0;
				while ((pos = buffer.indexOf("/*", pos)) > 0) {
					int endPos1 = buffer.indexOf("* /", pos);
					int endPos2 = buffer.indexOf("\n        ;", pos);
					int endPos3 = buffer.indexOf("\n", pos);

					if (endPos1 > 0
						&& (endPos1 < endPos2 || endPos2 == -1)
						&& (endPos1 < endPos3 || endPos3 == -1)) {

						buffer.replace(pos, endPos1 + 3, "");
					}
					else if (
						endPos2 > 0
							&& (endPos2 <= endPos3 || endPos3 == -1)) {

						buffer.replace(pos, endPos2, "void");
					}
					else if (endPos3 > 0) {
						buffer.replace(pos, endPos3, "void,");
					}
					else {
						System.err.println("Cannot find end of comment!");
					}
					pos++;
				}

				final FileWriter writer =
					new FileWriter(
						new File(
							AOLCreator.computeFilteredFileName(
								this.fileName)));
				writer.write(buffer.toString());
				writer.close();

				System.out.println(
					MultilingualManager.getString(
						"FILTERING_DONE",
						AOLCreator.class));
			}
			catch (final FileNotFoundException e) {
				e.printStackTrace(Output.getInstance().errorOutput());
			}
			catch (final IOException e) {
				e.printStackTrace(Output.getInstance().errorOutput());
			}
		}
	}

	private void replace(
		final StringBuffer buffer,
		final String anOldString,
		final String aNewString) {

		System.out.print("Replacing \"");
		System.out.print(
			anOldString.replaceAll("\\n", "\\n").substring(
				0,
				Math.min(anOldString.length(), 35)));
		System.out.print("\" with \"");
		System.out.print(
			aNewString.replaceAll("\\n", "\\n").substring(
				0,
				Math.min(aNewString.length(), 35)));
		System.out.print('\"');

		final int length = anOldString.length();
		int pos = 0;
		int changeCount = 0;
		while ((pos = buffer.indexOf(anOldString, pos)) > -1) {
			buffer.replace(pos, pos + length, aNewString);
			pos++;
			changeCount++;
		}
		if (changeCount == 0) {
			System.out.println(" - Not found");
		}
		else {
			System.out.print(" - ");
			System.out.print(changeCount);
			System.out.println(" found");
		}
		System.out.flush();
	}
	private IAbstractLevelModel parse(
		final boolean enableSemanticActions,
		final int aModelType) {

		System.out.print(
			MultilingualManager.getString("PARSING", AOLCreator.class));

		IAbstractLevelModel aLevelModel = null;
		if (aModelType == AOLCreator.AOL_CODE) {
			aLevelModel =
				Factory.getInstance().createCodeLevelModel(
					"Code-level model built using AOLCreator");
		}
		else if (aModelType == AOLCreator.AOL_IDIOM) {
			aLevelModel =
				Factory.getInstance().createIdiomLevelModel(
					"Idiom-level model built using AOLCreator");
		}

		try {
			final LineNumberReader reader =
				new LineNumberReader(
					new InputStreamReader(
						new FileInputStream(
							AOLCreator.computeFilteredFileName(
								this.fileName))));

			// Yann 2007/02/01: Classes and ghosts
			// I first populate the model with classes
			// so that I can build ghosts when appropriate.
			final StringBuffer buffer = new StringBuffer();
			String readLine;
			int numberOfClasses = 0;
			while ((readLine = reader.readLine()) != null) {
				buffer.append(readLine);
				buffer.append('\n');
				if (readLine.indexOf("CLASS") == 0) {
					// Yann 2004/12/14: Giulio's comment!
					// Giulio pointed out to me that we should count only
					// class which definitions start at the very beginning
					// of the line, because the keyword "CLASS" may appear
					// elsewhere on the line due to the AOL file format.
					numberOfClasses++;

					final StringTokenizer tokenizer =
						new StringTokenizer(readLine);
					tokenizer.nextToken();
					final String className = tokenizer.nextToken();
					aLevelModel.addActor(
						Factory.getInstance().createClass(className));
				}
			}
			reader.close();
			System.out.print(' ');
			System.out.print(numberOfClasses);
			System.out.println(
				MultilingualManager.getString("CLASSES", AOLCreator.class));

			if (aModelType == AOLCreator.AOL_CODE) {
				final AOLCodeParser parser =
					new AOLCodeParser(
						new AOLLexer(new StringReader(buffer.toString())));
				parser.setCodeLevelModel((ICodeLevelModel) aLevelModel);
				parser.enableSemanticActions(enableSemanticActions);
				aLevelModel = (ICodeLevelModel) parser.parse().value;
			}
			else if (aModelType == AOLCreator.AOL_IDIOM) {
				final AOLIdiomParser parser =
					new AOLIdiomParser(
						new AOLLexer(new StringReader(buffer.toString())));
				parser.setIdiomLevelModel((IIdiomLevelModel) aLevelModel);
				parser.enableSemanticActions(enableSemanticActions);
				aLevelModel = (IIdiomLevelModel) parser.parse().value;
			}

			System.out.println(
				MultilingualManager.getString(
					"PARSING_DONE",
					AOLCreator.class));
		}
		catch (final FileNotFoundException e) {
			e.printStackTrace(Output.getInstance().errorOutput());
		}
		catch (final IOException e) {
			e.printStackTrace(Output.getInstance().errorOutput());
		}
		catch (final Exception e) {
			e.printStackTrace(Output.getInstance().errorOutput());
		}

		return aLevelModel;
	}
}

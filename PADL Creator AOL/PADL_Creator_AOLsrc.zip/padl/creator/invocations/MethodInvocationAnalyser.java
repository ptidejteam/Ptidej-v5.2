/*
 * (c) Copyright 2001-2004 Yann-Ga�l Gu�h�neuc,
 * University of Montr�al.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the author, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN,
 * ANY LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHOR IS ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.creator.invocations;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import padl.analysis.IAnalysis;
import padl.kernel.IAbstractMethod;
import padl.kernel.IAbstractModel;
import padl.kernel.IDelegatingMethod;
import padl.kernel.IElement;
import padl.kernel.IEntity;
import padl.kernel.IMethod;
import padl.kernel.IMethodInvocation;
import padl.kernel.exception.ModelDeclarationException;
import padl.kernel.impl.Factory;
import util.io.Output;

/**
 * @author Yann-Ga�l Gu�h�neuc
 * @since  2007/01/29
 */
public class MethodInvocationAnalyser implements IAnalysis {
	private String cldFile;
	public void setCLDFile(final String aCLDFile) {
		this.cldFile = aCLDFile;
	}
	public String getCLDFile() {
		return this.cldFile;
	}
	public IAbstractModel invoke(final IAbstractModel anAbstractModel) {
		try {
			final IAbstractModel newAbstractModel =
				(IAbstractModel) anAbstractModel.clone();
			final BufferedReader reader =
				new BufferedReader(new FileReader(this.cldFile));
			final List listOfModifiedMethods = new ArrayList();

			// A typical line looks like:
			// invoke  ADM_Process::checkConfiguration(IMSBoolean&)    "ADM_Process::getFileModificationTime"

			String line;
			int numberOfInvocations = 0;
			int numberOfFailures = 0;
			int firstIndex;
			int secondIndex;
			while ((line = reader.readLine()) != null) {
				numberOfInvocations++;

				firstIndex = line.indexOf('\t') + 1;
				secondIndex = line.indexOf("::", firstIndex);
				final String sourceTypeName =
					line.substring(firstIndex, secondIndex);

				firstIndex = secondIndex + 2;
				secondIndex = line.indexOf('(', firstIndex);
				final String sourceMethodName =
					line.substring(firstIndex, secondIndex);

				// Yann 2007/010/29: Lazy
				// For the sake of simplicity, I forget for now about parameters.

				firstIndex = line.indexOf('"', secondIndex) + 1;
				secondIndex = line.indexOf("::", firstIndex);
				final String targetTypeName =
					line.substring(firstIndex, secondIndex);

				firstIndex = secondIndex + 2;
				secondIndex = line.indexOf('"', firstIndex);
				final String targetMethodName =
					line.substring(firstIndex, secondIndex);

				IEntity sourceType = null;
				IAbstractMethod sourceMethod = null;
				IEntity targetType = null;
				IAbstractMethod targetMethod = null;

				try {
					sourceType =
						(IEntity) newAbstractModel.getActorFromName(
							sourceTypeName);

					sourceMethod =
						(IAbstractMethod) sourceType.getActorFromName(
							sourceMethodName);

					targetType =
						(IEntity) newAbstractModel.getActorFromName(
							targetTypeName);
					if (targetType == null) {
						targetType =
							Factory.getInstance().createGhost(targetTypeName);
						newAbstractModel.addActor(targetType);
					}

					targetMethod =
						(IAbstractMethod) targetType.getActorFromName(
							targetMethodName);
					if (targetMethod == null) {
						targetMethod =
							Factory.getInstance().createMethod(
								targetMethodName);
						targetType.addActor(targetMethod);
					}

					final IMethodInvocation methodInvocation =
						Factory.getInstance().createMethodInvocation(
							IMethodInvocation.INSTANCE_INSTANCE,
							1,
							targetMethod.getVisibility(),
							targetType);
					sourceMethod.addActor(methodInvocation);

					listOfModifiedMethods.add(
						new Couple(sourceType, sourceMethod));

				}
				catch (final ModelDeclarationException e) {
					e.printStackTrace(Output.getInstance().errorOutput());
				}
				catch (final NullPointerException e) {
					numberOfFailures++;

					//	System.err.print(sourceTypeName);
					//	System.err.print(" -> ");
					//	System.err.println(sourceType);
					//	System.err.print(sourceMethodName);
					//	System.err.print(" -> ");
					//	if (sourceMethod == null) {
					//		System.err.println("null");
					//	}
					//	else {
					//		System.err.println(sourceMethod.getName());
					//	}
					//	System.err.print(targetTypeName);
					//	System.err.print(" -> ");
					//	System.err.println(targetType);
					//	System.err.print(targetMethodName);
					//	System.err.print(" -> ");
					//	if (targetMethod == null) {
					//		System.err.println("null");
					//	}
					//	else {
					//		System.err.println(targetMethod.getName());
					//	}
					//	System.err.println();
				}
			}

			System.out.print("Added ");
			System.out.print(numberOfInvocations - numberOfFailures);
			System.out.print(" method invocations (");
			System.out.print(numberOfFailures);
			System.out.print(" failures for ");
			System.out.print(numberOfInvocations);
			System.out.println(" potential invocations)");

			// Yann 2007/02/02: Delegations
			// I go through the method in which only one method invocation 
			// has been added to convert them into delegations.
			int numberOfAddedDelegations = 0;
			final Iterator iteratorOnModifiedMethods =
				listOfModifiedMethods.iterator();
			while (iteratorOnModifiedMethods.hasNext()) {
				final Couple couple =
					(Couple) iteratorOnModifiedMethods.next();
				final IEntity entity = couple.getDeclaringEntity();
				final IAbstractMethod method = couple.getModifiedMethod();

				if (method instanceof IMethod
					&& method.getNumberOfActors(IMethodInvocation.class) == 1) {

					final IMethodInvocation methodInvocation =
						(IMethodInvocation) method
							.getIteratorOnActors(IMethodInvocation.class)
							.next();

					try {
						final IDelegatingMethod delegation =
							Factory.getInstance().createDelegatingMethod(
								method.getName(),
								Factory
									.getInstance()
									.createAssociationRelationship(
									"DuMmY",
									methodInvocation.getTargetEntity(),
									1),
								(IMethod) methodInvocation.getCalledMethod());

						final Iterator iterator =
							method.getIteratorOnActors();
						while (iterator.hasNext()) {
							final IElement element =
								(IElement) iterator.next();
							delegation.addActor(element);
						}

						entity.removeActorFromID(method.getID());
						entity.addActor(delegation);
						numberOfAddedDelegations++;
					}
					catch (final ModelDeclarationException e) {
						e.printStackTrace(Output.getInstance().errorOutput());
					}
				}
			}

			Output.getInstance().normalOutput().print("Added ");
			Output.getInstance().normalOutput().print(
				numberOfAddedDelegations);
			Output.getInstance().normalOutput().println(" delegations");

			return newAbstractModel;
		}
		catch (final CloneNotSupportedException cnse) {
			cnse.printStackTrace(Output.getInstance().errorOutput());
		}
		catch (final FileNotFoundException e) {
			Output.getInstance().errorOutput().println("No CLD file given?");
			e.printStackTrace(Output.getInstance().errorOutput());
		}
		catch (final IOException e) {
			e.printStackTrace(Output.getInstance().errorOutput());
		}
		return null;
	}
	public String getName() {
		return "Method invocation adder";
	}
}
